import java.util.List;

import org.codetome.hexameter.core.api.Hexagon;
import org.codetome.hexameter.core.api.HexagonalGrid;


public abstract class SearchAlgorithm {
	
	protected HexagonalGrid<HexData> hexagonalGrid = null;
	protected final List<Hexagon<HexData>> path = null;
	
	protected Hexagon<HexData> root;
	protected Hexagon<HexData> goal;
	
	public void getPathData(){
		hexagonalGrid = HexPrimary.hexagonalGrid;
		root = HexPrimary.root;
		goal = HexPrimary.goal;
	}
	
	public abstract boolean search();
}
