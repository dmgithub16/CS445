
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import org.codetome.hexameter.core.api.Hexagon;




public class BreadthFirstSearch extends SearchAlgorithm {

	public BreadthFirstSearch() {
		this.hexagonalGrid = HexPrimary.hexagonalGrid;
	}

	@Override
	public boolean search() {
		
		//Update our path data before searching
		getPathData();
		
		final List<Hexagon<HexData>> explored = new LinkedList<Hexagon<HexData>>();
		final Queue<Hexagon<HexData>> queue = new LinkedList<Hexagon<HexData>>();
		Hexagon<HexData> current = null;
		//If the root and goal are the same, just return it
		if(root.equals(goal)){
			//add it to the explored list
			explored.add(root);
			return true;
		}
		
		//the root isn't the goal so,
		//add the root to the queue
		queue.add(root);
		
		//and add it to the explored list
		explored.add(root);
		
		//go through the queue until it is empty
		while( !queue.isEmpty() ){
			//get the next item in the queue and explored, make it the root
			current = queue.poll();
			explored.add(current);
			//Check to see if this is the goal	
			if( current.equals( goal ) ){
				System.out.println("Found goal at: " + current.getGridX()+ "/ Y: " + current.getGridY());

				//setting unweigthed path hexagons as visited by iterating through the queue
				for(Hexagon<HexData> hex : queue)
				{
					//checking data
					HexData data;
					if(!hex.getSatelliteData().isPresent()){
						data = new HexData();
					}else{
						data = hex.getSatelliteData().get();
					}
					data.setVisited(true);
					hex.setSatelliteData( data);
				}
				//setting explored hexagons as Opaque by iterating through the explored list
				for(Hexagon<HexData> hex : explored)
				{
					//checking data again
					HexData data;
					if(!hex.getSatelliteData().isPresent()){
						data = new HexData();
					}else{
						data = hex.getSatelliteData().get();
					}
					data.setOpaque(true);
					hex.setSatelliteData( data);
				}
				return true;
			}
			//probably not though, so
			else
			{
				//check the queue,
				if(hexagonalGrid.getNeighborsOf(current).isEmpty())
				{
					return false;
					
				}
				else
				{
					//and add neighbors if they exist.
					queue.addAll(hexagonalGrid.getNeighborsOf(current));
				}
			}
			explored.add(current);
			//remove the explored hexagon from queue, VERY IMPORTANT!
			queue.removeAll(explored);
		}
		//if the queue is empty and no goal,there is no path, bummer
		return false;
	}
}
