import static org.codetome.hexameter.core.api.HexagonOrientation.POINTY_TOP;
import static org.codetome.hexameter.core.api.HexagonalGridLayout.HEXAGONAL;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import org.codetome.hexameter.core.api.Hexagon;
import org.codetome.hexameter.core.api.HexagonOrientation;
import org.codetome.hexameter.core.api.HexagonalGrid;
import org.codetome.hexameter.core.api.HexagonalGridBuilder;
import org.codetome.hexameter.core.api.HexagonalGridCalculator;
import org.codetome.hexameter.core.api.HexagonalGridLayout;


public class HexPrimary {

	//Config variables

	//Grid defaults
	private static final int DEFAULT_GRID_WIDTH = 71;
	private static final int DEFAULT_GRID_HEIGHT = 71;
	private static final int DEFAULT_RADIUS = 10;
	private static final HexagonOrientation DEFAULT_ORIENTATION = POINTY_TOP;
	private static final HexagonalGridLayout DEFAULT_GRID_LAYOUT = HEXAGONAL;


	//Grid config
	public static HexagonalGrid<HexData> hexagonalGrid;
	private static int gridWidth = DEFAULT_GRID_WIDTH;
	private static int gridHeight = DEFAULT_GRID_HEIGHT;
	private static int radius = DEFAULT_RADIUS;
	private static HexagonOrientation orientation = DEFAULT_ORIENTATION;
	private static HexagonalGridLayout hexagonGridLayout = DEFAULT_GRID_LAYOUT;
	private static SearchAlgorithm currentSearch;

	//Unsure
	private static HexagonalGridCalculator<HexData> hexagonalGridCalculator;

	//Colors
	private static final Color RED = null;

	//Pathing variables
	static Hexagon<HexData> root;
	static Hexagon<HexData> goal;

	//Clicks
	private static int Clicks = 1;

	public static void main(String[] args){
		HexagonalGridBuilder<HexData> builder = new HexagonalGridBuilder<HexData>();
		builder.setGridWidth(gridWidth).setGridHeight(gridHeight);
		builder.setRadius(radius).setOrientation(orientation);
		builder.setGridLayout(hexagonGridLayout);
		hexagonalGrid = builder.build();
		hexagonalGridCalculator = builder.buildCalculatorFor(hexagonalGrid);

		//Instantiate our testing search method (Breadth-first search)
		currentSearch = new BreadthFirstSearch();

		//Set up frame
		final JFrame frame = new JFrame();
		frame.setTitle( "Hexagon Pathfinding" );
		frame.setSize( 1000, 1000 );
		frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

		//Add hex grid drawing panel
		Container contentPane = frame.getContentPane();
		final JPanel hexPanel = new DrawingPanel();

		//Button for testing search 
		final JButton searchBtn = new JButton();
		searchBtn.setText("Search");

		//I hate JAVA GUI
		searchBtn.setPreferredSize(new Dimension (100, 50));

		contentPane.add( hexPanel );
		contentPane.add(searchBtn,  BorderLayout.LINE_END);

		//Add a mouse listener
		hexPanel.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(MouseEvent event) {

				Hexagon<HexData> hex = null;

				hex = hexagonalGrid.getByPixelCoordinate( event.getX(), event.getY() ).get();

				//If we've actually selected a hexagon
				if (hex != null) {

					//The hexagon's data
					HexData data;

					//If we don't have existing satellite data, create a new one for this hex
					if( !hex.getSatelliteData().isPresent() ){
						data = new HexData();
					}else{
						//Otherwise, just get the existing one
						data = hex.getSatelliteData().get();
					}

					//Swap the hexagon's selected state
					data.setSelected(!data.isSelected());

					if(Clicks == 1)
					{
						System.out.println( "Set root" );
						//Set root hexagon
						data.setRoot(!data.isRoot());
						root = hex;
						Clicks = 2;
					}
					else if(Clicks == 2)
					{
						//Set goal hexagon
						data.setGoal(!data.isGoal());
						goal = hex;
						Clicks = 1;
					}

					//Set the hexagon's satellite data once we've modified it
					hex.setSatelliteData( data );

					//Only print the position if we selected a hex
					System.out.println("X: " + hex.getGridX()+ "/ Y: " + hex.getGridY());

					//Repaint the panel with the new values
					hexPanel.repaint();
				}
			}
		});

		searchBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				//Lets give this sucker a wirl 

				Hexagon<HexData> root = null;
				Hexagon<HexData> goal = null;

				//get the root and goal hexagons from the grid
				for(Hexagon<HexData> hexagon : hexagonalGrid.getHexagons())
				{
					if(hexagon.getSatelliteData().isPresent() && hexagon.getSatelliteData().get().isRoot())
					{
						root = hexagon;
					}
					if(hexagon.getSatelliteData().isPresent() && hexagon.getSatelliteData().get().isGoal())
					{
						goal = hexagon;
					}
				}
				// feed the root and goal to our search algorithm	
				//If our search executes succesfully, the explored hexagon will be illuminated by the search
				//use gridCalculator to draw the line.
				if( currentSearch.search() ){

					List<Hexagon<HexData>> hexes = hexagonalGridCalculator.drawLine(root, goal);
					for(Hexagon<HexData> h : hexes){
						HexData data;

						//If we don't have existing satellite data, create a new one for this hex
						if( !h.getSatelliteData().isPresent() ){
							data = new HexData();
						}else{
							//Otherwise, just get the existing one
							data = h.getSatelliteData().get();
						}
						data.setPath(true);
						h.setSatelliteData(data);
					}
					hexPanel.repaint();
				}else{
					System.out.println("Didn't work bro");
				}
			}
		});
		//Finalize JFrame and display
		frame.validate();
		frame.setVisible( true );
	}

}
