import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import org.codetome.hexameter.core.api.Hexagon;
import org.codetome.hexameter.core.api.HexagonalGrid;
import org.codetome.hexameter.core.api.Point;



public class HexagonalGridSearch<T extends HexData> {

	 private HexagonalGrid<T> hexagonalGrid = null;
	 private final List<Hexagon<T>> path = null;

	    public HexagonalGridSearch(HexagonalGrid<T> hexagonalGrid) {
	        this.hexagonalGrid = hexagonalGrid;
	    }
	    
	    public boolean BFS(final Hexagon<T> root, final Hexagon<T> goal) {

	    	
	    		final List<Hexagon<T>> explored = new LinkedList<>();
		        final Queue<Hexagon<T>> queue = new LinkedList<>();
	    	    Hexagon<T> current = null;
				
				
	    	    //If the root and goal are the same, just return it
	    	    if(root.equals(goal))
	    	    {
	    	    	//add it to the explored list
	    	    	explored.add(root);
	    	    	return true;
	    	    }
	    	    //the root isn't the goal so,
	    	    //add the root to the queue
	    	    queue.add(root);
	    	    //and add it to the explored list
	    	    explored.add(root);
	    	    //go through the queue until it is empty
	    	    while(!queue.isEmpty())
	    	    {
	    	    	//get the next item in the queue and explored, make it the root
	    	    	current = queue.remove();
	    	    	explored.add(current);
	    	    	//Check to see if this is the goal	
	    	    	if(current.equals(goal))
	    	    	{
	    	    		System.out.println("Found goal at: " + current.getGridX()+ "/ Y: " + current.getGridY());
	    	    		
	    	    		//setting unweigthed path hexagons as visited by iterating through the queue
	    	    		for(Hexagon<T> hex : queue)
	    	    		{
	    	    			//checking data
	    	    			T data;
	    	    			if(!hex.getSatelliteData().isPresent()){
	    						data = (T) new HexData();
	    					}else{
	    						data = hex.getSatelliteData().get();
	    					}
	    	    			data.setVisited(true);
	    	    			hex.setSatelliteData((T) data);
	    	    		}
	    	    		//setting explored hexagons as Opaque by iterating through the explored list
	    	    		for(Hexagon<T> hex : explored)
	    	    		{
	    	    			//checking data again
	    	    			HexData data;
	    	    			if(!hex.getSatelliteData().isPresent()){
	    						data = new HexData();
	    					}else{
	    						data = hex.getSatelliteData().get();
	    					}
	    	    			data.setOpaque(true);
	    	    			hex.setSatelliteData((T) data);
	    	    		}
	    	    		return true;
	    	    	}
	    	    	//probably not though, so
	    	    	else
	    	    	{
	    	    		//check the queue,
	    	    		if(hexagonalGrid.getNeighborsOf(current).isEmpty())
	    	    		{
	    	    			return false;
	    	    		}
	    	    		else
	    	    			//and add neighbors if they exist.
	    	    			queue.addAll(hexagonalGrid.getNeighborsOf(current));
	    	    	}
	    	    	explored.add(current);

	    	    }
	    	    //if the queue is empty and no goal,there is no path, bummer
	    	    return false;
	    }
}
